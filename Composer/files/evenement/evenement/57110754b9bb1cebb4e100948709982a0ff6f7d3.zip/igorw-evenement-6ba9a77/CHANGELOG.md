CHANGELOG
=========

* 2.0.0 (2012-11-02)

 * Require PHP >=5.4.0
 * Added EventEmitterTrait
 * Removed EventEmitter2
