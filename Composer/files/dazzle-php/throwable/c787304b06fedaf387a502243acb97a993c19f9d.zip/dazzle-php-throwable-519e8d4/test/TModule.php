<?php

namespace Dazzle\Throwable\Test;

class TModule extends TUnit
{}
