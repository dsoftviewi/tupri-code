<?php

namespace Dazzle\Throwable\Test;

class Callback
{
    public function __invoke()
    {}
}