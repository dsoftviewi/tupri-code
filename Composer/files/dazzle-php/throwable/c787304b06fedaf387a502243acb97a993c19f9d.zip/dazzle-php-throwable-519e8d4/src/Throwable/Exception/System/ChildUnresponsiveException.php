<?php

namespace Dazzle\Throwable\Exception\System;

use Dazzle\Throwable\Exception\SystemException;

class ChildUnresponsiveException extends SystemException
{}
