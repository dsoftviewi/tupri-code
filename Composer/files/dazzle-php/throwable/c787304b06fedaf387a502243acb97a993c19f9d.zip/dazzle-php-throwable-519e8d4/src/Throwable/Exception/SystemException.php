<?php

namespace Dazzle\Throwable\Exception;

use Dazzle\Throwable\Exception;

class SystemException extends Exception
{}
