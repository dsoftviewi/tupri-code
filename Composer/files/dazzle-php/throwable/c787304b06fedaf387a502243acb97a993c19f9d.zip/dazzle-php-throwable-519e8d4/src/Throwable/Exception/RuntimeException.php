<?php

namespace Dazzle\Throwable\Exception;

use Dazzle\Throwable\Exception;

class RuntimeException extends Exception
{}
