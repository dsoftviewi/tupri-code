<?php

namespace Dazzle\Throwable\Exception\System;

use Dazzle\Throwable\Exception\SystemException;

class TaskIncompleteException extends SystemException
{}
