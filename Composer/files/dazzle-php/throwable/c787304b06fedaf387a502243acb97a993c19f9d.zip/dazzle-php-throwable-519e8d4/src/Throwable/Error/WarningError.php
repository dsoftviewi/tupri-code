<?php

namespace Dazzle\Throwable\Error;

use Dazzle\Throwable\Error;

class WarningError extends Error
{}
