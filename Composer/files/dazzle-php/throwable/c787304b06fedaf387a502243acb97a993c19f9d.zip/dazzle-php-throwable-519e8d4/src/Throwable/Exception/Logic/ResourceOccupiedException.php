<?php

namespace Dazzle\Throwable\Exception\Logic;

use Dazzle\Throwable\Exception\LogicException;

class ResourceOccupiedException extends LogicException
{}
