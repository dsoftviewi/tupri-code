<?php

namespace Dazzle\Throwable\Exception\Runtime;

use Dazzle\Throwable\Exception\RuntimeException;

class OverflowException extends RuntimeException
{}
