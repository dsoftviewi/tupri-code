<?php

namespace Dazzle\Throwable\Exception\Logic;

use Dazzle\Throwable\Exception\LogicException;

class ResourceUndefinedException extends LogicException
{}
