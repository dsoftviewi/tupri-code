<?php

namespace Dazzle\Throwable\Exception\System;

use Dazzle\Throwable\Exception\SystemException;

class ParentUnresponsiveException extends SystemException
{}
