<?php

namespace Dazzle\Throwable\Error;

use Dazzle\Throwable\Error;

class FatalError extends Error
{}
