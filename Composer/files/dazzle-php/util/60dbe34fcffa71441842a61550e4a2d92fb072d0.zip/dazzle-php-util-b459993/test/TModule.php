<?php

namespace Dazzle\Util\Test;

class TModule extends TUnit
{}
