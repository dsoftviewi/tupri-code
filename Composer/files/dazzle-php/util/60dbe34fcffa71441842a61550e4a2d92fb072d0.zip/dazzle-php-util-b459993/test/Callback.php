<?php

namespace Dazzle\Util\Test;

class Callback
{
    public function __invoke()
    {}
}