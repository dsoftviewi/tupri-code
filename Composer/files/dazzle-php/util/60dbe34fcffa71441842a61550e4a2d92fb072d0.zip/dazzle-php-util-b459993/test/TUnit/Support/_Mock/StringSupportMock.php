<?php

namespace Dazzle\Util\Test\TUnit\Support\_Mock;

use Dazzle\Util\Support\StringSupport;

class StringSupportMock extends StringSupport
{}
