<?php

namespace Dazzle\Util\Test\TUnit\Support\_Mock;

use Dazzle\Util\Support\TimeSupport;

class TimeSupportMock extends TimeSupport
{}

