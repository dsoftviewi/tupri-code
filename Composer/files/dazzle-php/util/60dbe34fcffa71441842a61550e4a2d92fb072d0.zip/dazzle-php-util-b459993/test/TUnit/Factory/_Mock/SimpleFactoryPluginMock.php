<?php

namespace Dazzle\Util\Test\TUnit\Factory\_Mock;

use Dazzle\Util\Factory\SimpleFactoryPlugin;

class SimpleFactoryPluginMock extends SimpleFactoryPlugin
{}
