<?php

namespace Dazzle\Util\Test\TUnit\Factory\_Mock;

use Dazzle\Util\Factory\FactoryInterface;
use Dazzle\Util\Factory\FactoryTrait;

class FactoryMock implements FactoryInterface
{
    use FactoryTrait;
}
