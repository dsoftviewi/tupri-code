<?php

namespace Dazzle\Util\Test\TUnit\Factory\_Mock;

use Dazzle\Util\Factory\SimpleFactoryInterface;
use Dazzle\Util\Factory\SimpleFactoryTrait;

class SimpleFactoryMock implements SimpleFactoryInterface
{
    use SimpleFactoryTrait;
}
