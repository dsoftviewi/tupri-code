<?php

namespace Dazzle\Util\Test\TUnit\Support\_Mock;

use Dazzle\Util\Support\GeneratorSupport;

class GeneratorSupportMock extends GeneratorSupport
{}
