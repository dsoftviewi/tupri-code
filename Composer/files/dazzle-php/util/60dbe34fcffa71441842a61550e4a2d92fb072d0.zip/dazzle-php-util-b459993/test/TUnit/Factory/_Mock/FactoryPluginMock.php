<?php

namespace Dazzle\Util\Test\TUnit\Factory\_Mock;

use Dazzle\Util\Factory\FactoryPlugin;

class FactoryPluginMock extends FactoryPlugin
{}
