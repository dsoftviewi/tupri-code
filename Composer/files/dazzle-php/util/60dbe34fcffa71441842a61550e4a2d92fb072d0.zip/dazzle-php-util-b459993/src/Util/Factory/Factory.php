<?php

namespace Dazzle\Util\Factory;

class Factory implements FactoryInterface
{
    use FactoryTrait;
}
