<?php

namespace Dazzle\Util\Factory;

class SimpleFactory implements SimpleFactoryInterface
{
    use SimpleFactoryTrait;
}
